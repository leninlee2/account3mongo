package com.example.demo.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.data.AccountData;
import com.example.demo.data.TransferData;
import com.example.demo.model.Account;
import com.example.demo.model.Transfer;

@Controller
public class TransferController {

	@RequestMapping(value = "/transfer", method = RequestMethod.GET)	
	public String Index(ModelMap model) {
		//MatrizModel view = new MatrizModel();
		//model.addAttribute("name", "This is the result");		
		return "transfer";
	}
	
	@RequestMapping(value = "/transferedit", method = RequestMethod.GET)	
	public String Edit(ModelMap model) {
		//List<Account> account = new AccountData().findAll();
		//model.addAttribute("name", "This is the result");		
		return "transferedit";
	}
	
	@RequestMapping(value = "/savetransfer", method = RequestMethod.POST)	
	public String SaveNewPerson(@RequestParam("oraccount") String oraccount,
			@RequestParam("desaccount") String desaccount,
			@RequestParam("value") String value
			, Model model ) {
		
		TransferData data = new TransferData();
		Transfer tt = new Transfer();
		tt.startid = Integer.parseInt(oraccount);
		tt.endid = Integer.parseInt(desaccount);
		tt.status = 1;
		tt.value = Float.parseFloat(value);
		data.Save(tt);
				
		model.addAttribute("name", "Test");		
		return "saveddata";
	}
	
}
