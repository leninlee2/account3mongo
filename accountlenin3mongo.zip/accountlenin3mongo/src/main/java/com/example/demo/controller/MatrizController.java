package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;
//import org.springframework.ui.*;
//import org.springframework.web.*;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.example.demo.model.MatrizModel;

@Controller
public class MatrizController {
		
	//@GetMapping("/matrizrecord")
	@RequestMapping(value = "/matrizrecord", method = RequestMethod.GET)	
	public String Index(ModelMap model) {
		MatrizModel view = new MatrizModel();
		model.addAttribute("name", "This is the result");		
		return "matrizrecord";
	}

}
