package com.example.demo.data;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



//import javax.swing.tree.RowMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.example.demo.model.Person;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ServerAddress;
import com.mongodb.MongoCredential;
import com.mongodb.MongoClientOptions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonData {

	//@Autowired
    //JdbcTemplate jdbcTemplate;
	//SimpleDriverDataSource ds;
	
	@Autowired
    private IPersonRepository personRepository;
	
	public PersonData(IPersonRepository personRepository) {
		//ds = new SimpleDriverDataSource();
        //ds.setDriverClass(org.h2.Driver.class);
        //ds.setUrl("jdbc:h2:~/test;DB_CLOSE_ON_EXIT=FALSE;AUTO_SERVER=TRUE");
        //ds.setUsername("sa");
        //ds.setPassword("");		
		this.personRepository = personRepository;
	}
	
	public Person findById(int id) {
	    //return jdbcTemplate.queryForObject("select * from Person where id=?", new Object[] {
	    //        id
	    //    },
	    //    new BeanPropertyRowMapper<Person>(Person.class));
		String res = String.valueOf(id);
		return personRepository.findById(res).get();
	}
	
	public List<Person> findAll() {
		List<Person> result = new ArrayList<Person>();
		try {
			result = personRepository.findAll();
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
		/*
		List<Person> result = new ArrayList<Person>();
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        //result = temp.query("select * from PERSON", new BeanPropertyRowMapper<Person>(Person.class));
	        result = temp.query("select * from PERSON", new PersonRowMapper());
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
		*/
		
		return result;
	}
	
	public void Save(Person person) {
		/*
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        String command = "insert into Person(CPF,NAME,BIRTDATE) values(?,?,?)";
	        temp.update(command,new Object[] {person.cpf,person.name,person.birthday} );
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
		*/
		personRepository.save(person);
	}
	
	public void SaveCompany(Person person) {
		/*
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        String command = "insert into Person(CNPJ,NAME,EIN) values(?,?,?)";
	        temp.update(command,new Object[] {person.cpf,person.name,person.ein} );
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
		*/
	}
	
}


//class PersonRowMapper implements RowMapper<Person> {
	/*
    @Override
    public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
        Person ps = new Person();
        ps.id =   rs.getInt("id");
        ps.name = rs.getString("name");
        ps.cpf =  rs.getString("CPF");
        return ps;
    }
    */
//}