package com.example.demo.data;

import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

//import javax.swing.tree.RowMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import com.example.demo.model.Account;
import com.example.demo.model.Person;
import com.example.demo.model.Transfer;

public class TransferData {

	@Autowired
    JdbcTemplate jdbcTemplate;
	SimpleDriverDataSource ds;
	
	public TransferData() {
		ds = new SimpleDriverDataSource();
        ds.setDriverClass(org.h2.Driver.class);
        ds.setUrl("jdbc:h2:~/test;DB_CLOSE_ON_EXIT=FALSE;AUTO_SERVER=TRUE");
        ds.setUsername("sa");
        ds.setPassword("");		
	}
	
	public Transfer findById(int id) {
	    return jdbcTemplate.queryForObject("select * from Transfer where id=?", new Object[] {
	            id
	        },
	        new BeanPropertyRowMapper<Transfer>(Transfer.class));
	}
	
	public List<Transfer> findAll() {
		List<Transfer> result = new ArrayList<Transfer>();
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        result = temp.query("select * from Transfer", new TransferRowMapper());
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
		
		return result;
	}
	
	public void Save(Transfer transfer) {
		try {
			
	        JdbcTemplate temp = new JdbcTemplate(ds);
	        String command = "insert into TRANSFER(STARTID,ENDID,STATUS,DATETRANSFER,VALUE) values(?,?,?,CURRENT_TIMESTAMP(),?)";
	        temp.update(command,new Object[] {transfer.startid,transfer.endid,transfer.status,transfer.value} );
	
		}catch(Exception ex) {
			//LOGGER.error(ex.getMessage(), ex);
			System.out.println(ex.getMessage());
		}
	}
	
}

class TransferRowMapper implements RowMapper<Transfer> {
    @Override
    public Transfer mapRow(ResultSet rs, int rowNum) throws SQLException {
    	Transfer ps = new Transfer();
        ps.id =   rs.getInt("id");
        ps.startid = rs.getInt("startid");
        ps.endid =  rs.getInt("endid");
        ps.datetransfer = rs.getDate("datetransfer");
        ps.status = rs.getInt("status");
        return ps;
    }
}
