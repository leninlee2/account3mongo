package com.example.demo.model;

import org.springframework.ui.Model;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.ModelAttribute;

public class MatrizModel {

	public String name;
	public List<Person> persons;
	
	//@ModelAttribute("name")
	public String XName() {
		return "My Name";		
	}
}
