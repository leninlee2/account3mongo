package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import com.example.demo.data.AccountData;
import com.example.demo.model.Account;
import com.example.demo.model.MatrizModel;

@Controller
public class MainAccountController {

	//@RequestMapping("/z")
	//@ResponseBody
	//public String Index() {		
	//	return "Testing";
	//}
	
	@RequestMapping(value = "/account", method = RequestMethod.GET)	
	public String Index(ModelMap model) {
		//MatrizModel view = new MatrizModel();
		//model.addAttribute("name", "This is the result");		
		return "account";
	}
	
	@RequestMapping(value = "/newmatrix", method = RequestMethod.GET)	
	public String NewMatrix(Model model) {
		MatrizModel view = new MatrizModel();
		//ModelMap model = new ModelMap();
		//model.addAttribute("name", "This is the result");		
		return "newaccountm";
	}
	
	@RequestMapping(value = "/newclient", method = RequestMethod.GET)	
	public String NewClient(Model model) {
		MatrizModel view = new MatrizModel();
		//ModelMap model = new ModelMap();
		//model.addAttribute("name", "This is the result");		
		return "newaccountc";
	}
	
	@RequestMapping(value = "/savenewmatrix", method = RequestMethod.POST)	
	public String SaveNewPerson(@RequestParam("clientid") String clientid,
			@RequestParam("name") String name, Model model ) {
		
		AccountData data = new AccountData();
		Account account = new Account();
		account.name = name;
		account.clientid = Integer.parseInt(clientid);
		data.SaveMatrixAccount(account);
				
		model.addAttribute("name", name);		
		return "saveddata";
	}
	
	@RequestMapping(value = "/savenewclientaccount", method = RequestMethod.POST)	
	public String SaveNewCompany(@RequestParam("clientid") String clientid,
			@RequestParam("name") String name,
			@RequestParam("mmatriz") String mmatriz
			, Model model ) {
		
		AccountData data = new AccountData();
		Account account = new Account();
		account.name = name;
		account.clientid = Integer.parseInt(clientid);
		account.mmatriz = Integer.parseInt(mmatriz);
		data.SaveChield(account);
		
		System.out.println(clientid);
		
		model.addAttribute("name", clientid);		
		return "saveddata";
	}
	
	
}
