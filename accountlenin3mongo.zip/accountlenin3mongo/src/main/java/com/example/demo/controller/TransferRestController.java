package com.example.demo.controller;

import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.data.IPersonRepository;
import com.example.demo.data.PersonData;
import com.example.demo.model.Person;

@RestController
public class TransferRestController {
	
    private IPersonRepository personRepository;
	
	public TransferRestController(IPersonRepository personRepository) {
		this.personRepository = personRepository;		
	}
	
	@RequestMapping("/transferquery")
    public List<Person> TransferQuery() {
		List<Person> persons = new PersonData(personRepository).findAll();
		//Person ps = new Person();
		//ps.cpf = "123456";
		//persons.add(ps);
		
        return persons;
    }

}
