package com.example.demo.model;

import java.util.Date;

public class Transfer {
	public int id;
	public int startid;
	public int endid;
	public Date datetransfer;
	public int status;
	public float value;
}
