package com.example.demo.model;

import java.io.Serializable;
import java.util.Date;
import lombok.Getter;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

//@Getter
 
@Document(collection = "person")
public class Person  implements Serializable {

	@Id
	public String id;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String cpf;
	public String name;
	//public Date birthday;
	//public String cnpj;
	//public String ein;
	
	public Person(String cpf,String name) {
	   this.cpf = cpf;
	   this.name = name;
	}
	
}
