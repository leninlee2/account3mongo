package com.example.demo.controller;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.ModelMap;
import org.springframework.ui.Model;
//import org.springframework.ui.*;
//import org.springframework.web.*;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.data.IPersonRepository;
import com.example.demo.data.PersonData;
import com.example.demo.model.MatrizModel;
import com.example.demo.model.Person;
import org.springframework.jdbc.core.JdbcTemplate;


@Controller
public class PersonController {
	
	SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	private IPersonRepository personRepository;
	
	public PersonController(IPersonRepository personRepository) {
		this.personRepository = personRepository;		
	}
	
	@RequestMapping(value = "/person", method = RequestMethod.GET)	
	public String Index(ModelMap model) {
		MatrizModel view = new MatrizModel();
		try {
			view.persons = new PersonData(personRepository).findAll();
			model.addAttribute("name", "This is the result");		
			//model.addAttribute("persons", view.persons);
			//model.addAttribute("number", view.persons.size());			
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
			model.addAttribute("name", "This is the result");
		}
		
		return "person";
	}
	
	@RequestMapping(value = "/newperson", method = RequestMethod.GET)	
	public String NewPerson(Model model) {
		MatrizModel view = new MatrizModel();
		//ModelMap model = new ModelMap();
		//model.addAttribute("name", "This is the result");		
		return "newperson";
	}
	
	@RequestMapping(value = "/newcompany", method = RequestMethod.GET)	
	public String NewCompany(Model model) {
		MatrizModel view = new MatrizModel();
		//ModelMap model = new ModelMap();
		//model.addAttribute("name", "This is the result");		
		return "newcompany";
	}
	
	@RequestMapping(value = "/savenewperson", method = RequestMethod.POST)	
	public String SaveNewPerson(@RequestParam("cpf") String cpf,
			@RequestParam("name") String name,
			@RequestParam("birthday") String birthday, Model model ) {
		
		PersonData pd = new PersonData(personRepository);
		Person person = new Person("","");
		person.cpf = cpf;
		person.name = name;
		/*
		try {
			person.birthday = (Date) format.parse(birthday);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		pd.Save(person);
		
		model.addAttribute("name", name);		
		return "saveddata";
	}
	
	@RequestMapping(value = "/savenewcompany", method = RequestMethod.POST)	
	public String SaveNewCompany(@RequestParam("cnpj") String cnpj,
			@RequestParam("name") String name,
			@RequestParam("ein") String ein, Model model ) {
		
		PersonData pd = new PersonData(personRepository);
		Person person = new Person("","");
		person.cpf = cnpj;
		person.name = name;
		//person.ein = ein;
		
		pd.SaveCompany(person);
		
		model.addAttribute("name", name);		
		return "saveddata";
	}
	


}
